//
//  main.cpp
//  Assignment4
//
//  Created by Victor Chen on 7/30/15.
//  Copyright (c) 2015 Victor Chen. All rights reserved.
//

#include <iostream>
#include "Airplane.h"

int main(int argc, const char * argv[])
{
    Airplane a;
    a.showMenu();
    
    return 0;
}

